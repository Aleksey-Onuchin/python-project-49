### Hexlet tests and linter status:
[![Actions Status](https://github.com/Aleksey-Onuchin/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Aleksey-Onuchin/python-project-49/actions)

<a href="https://codeclimate.com/github/Aleksey-Onuchin/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/bb9cd4c04999465e625a/maintainability" /></a>

#asciinema link brain-even
https://asciinema.org/a/cUAFMIeqliYzGvCMMDdNgJnZ7

#asciinema link brain-calc
https://asciinema.org/a/PfqmJYO6FOGg4shXOphuNenON

#asciinema link brain-gcd
https://asciinema.org/a/fTVwaTyXxTGtcXnj7pMkUXzVl

#asciinema brain-progression
https://asciinema.org/a/IsUEcpxDuU1c1ThhGqgHPIa5y

#asciinema brain-prime
https://asciinema.org/a/KfMJP6Gyt7omeEWYcMyJ04SUJ
