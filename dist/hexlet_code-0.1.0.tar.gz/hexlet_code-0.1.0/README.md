### Hexlet tests and linter status:
[![Actions Status](https://github.com/Aleksey-Onuchin/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Aleksey-Onuchin/python-project-49/actions)

<a href="https://codeclimate.com/github/Aleksey-Onuchin/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/bb9cd4c04999465e625a/maintainability" /></a>

#asciinema link brain-even
https://asciinema.org/a/Xx8qz8Va4eTbkaZx1V3bdOn5r

#asciinema link brain-calc
https://asciinema.org/a/FY84kx5GPuRPdlpXrFJ1KWCGi

#asciinema link brain-gcd
https://asciinema.org/a/rPLyEM6pbiwNKjSgsydAdv7AN
