### Hexlet tests and linter status:
[![Actions Status](https://github.com/Aleksey-Onuchin/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Aleksey-Onuchin/python-project-49/actions)

<a href="https://codeclimate.com/github/Aleksey-Onuchin/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/bb9cd4c04999465e625a/maintainability" /></a>

#asciinema link brain-even
https://asciinema.org/a/hvItHqIXlmgWLorC7lqcgPlZq

#asciinema link brain-calc
https://asciinema.org/a/6xxGGKOZANNTPtMKP1zZrZPSC